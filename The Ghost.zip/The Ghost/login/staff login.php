<!DOCTYPE html> 
<head> 
    <title> Faculty Login</title>
    <link rel="stylesheet" href="staff.css">
</head>
<body>
    <fieldset>
      <div class="set">
    
</div>
<form  class="form1" method="post">
    <img id="logo" src="women-politician.png" alt="PecLogo" > 

    <input type="text" id="username" name="username" class="regno" placeholder="Register Number" ><br>
     <input type="password" id="password" name="password" class="pwd" placeholder="password" ><br>

     <input type="submit" value="Submit" id="btn" >
     <p id="text">Faculty - Login </p>  

 </form> 
 

 <?php

 if ($_SERVER["REQUEST_METHOD"] == "POST") {
     $servername = "localhost";
     $username = "root";
     $password = "";
     $dbname = "login";

     $conn = new mysqli($servername, $username, $password, $dbname);

     if ($conn->connect_error) {
         die("Connection failed: " . $conn->connect_error);
     }
     $username = $_POST["username"];
     $pass = $_POST["password"];

     // Fetch user's credentials from the database
     $sql = "SELECT * FROM venkat WHERE username = '$username'";
     $result = $conn->query($sql);

     if ($result->num_rows > 0) {
         $row = $result->fetch_assoc();
         $validUsername = $row["username"];
         $validPassword = $row["password"];

         // Verify the password
         if ($pass === $validPassword) {
             // Redirect to faculty.html
             echo "<script>window.location.href = 'master/faculty.php';</script>";
             exit();
         } else {
             echo "<script>alert('Invalid username or password. Please try again.');</script>";
         }
     } else {
         echo "<script>alert('User not found.');</script>";
     }

     $conn->close();
 }
 ?>

   </fieldset>
</body>


</html>