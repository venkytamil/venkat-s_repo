<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT</title>

   <link rel="stylesheet" href="styles.css"> 
   <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/themetypo.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


</head>

<!--  Nav bar  -->
<body>
    <nav>
        <ul class="size">
            <li><a href="#home" id="myBtn">Home</a></li>
            <li class="dropdown">
                <a  class="dropbtn" id="goDownButton">About Us</a>
               
            </li>

            <li class="dropdown">
                <a href="https://panimalar.ac.in/assets/pdf/program-curriculum/it2013.pdf" class="dropbtn">Academic Curriculum</a>
                 

                <li  class="dropdown">
                    <a href="#home" class="dropbtn" >Events</a>
                 </li>

                


                <li><a href="#home" onclick="scrollWin(0, 1700)">Innovation</a></li>
                <li><a href="#home">Academics</a></li>

                <li class="dropdown">
                    <a href="#" class="dropbtn">Login</a>
                       <div class="dropdown-content">
                        <a href="login/student login.html">Student Login</a>
                        <a href="login/staff login.php">Faculty Login</a>
                        <a href="login/admin login.html">Admin-Login</a>
                       </div>
                    
                        </div>
            </li>
        </ul>
    </nav>

<!--  Nav bar  -->

   

</div>

    <div class="img">
         <img src="css/c1.jpg" alt="img" sizes="auto"> 
         
         <div class="effect" > 
          <div class="dept-class">
            <p id="dept1">Powered by </p>
             <p id="dept2">Information Technology.</p>
             <p id="dept">Our intuition about the future is linear.</p>
           </div>
         </div>
    </div>

    <div class="space">
    <div class="one">   <img src="achievement.jpg" id="pics"> <h2 id="topic">Achievements</h2>
        <p id="about">"Great achievement requires personal force, determined-spirit, and self-confidence..."</p>
       <a href="" id="link"> Know More</a> 
    </div>

    <div class="two">   <img src="vision.jpg"  id="pics"> <h2 id="topic">Vision & Mission</h2> 
        <p id="about">"Vision sees the stars; mission carves <br> the path to reach them..."</p>
        <a href="" id="link"> Know More</a>
    </div>

    <div class="three">  <img src="placements.jpg"  id="pics"> <h2 id="topic">Placements</h2>
        <p id="about">"Pressure is nothing more than the shadow of great opportunity..."</p>
        <a href="" id="link"> Know More</a> 
    </div>


    </div>
     </div>


<!---  circle animi     -->
    <div class="container-fluid top-bg">

        <div class="container">

            <div id="company-hiring" data-vc-full-width="true" data-vc-full-width-init="true" class="">
                <div data-mk-stretch-content="true"
                    class="wpb_row vc_row vc_row-fluid jupiter-donut- mk-fullwidth-false  attched-false     js-master-row  mk-grid mk-in-viewport">




                    <div
                        class="vc_col-sm-12 wpb_column column_container cli  jupiter-donut- _ jupiter-donut-height-full">
                        <div class=" vc_custom_1588939614705">

                            <div id="text-block-41" class="mk-text-block  jupiter-donut- ">

                                <h2 class="hme_ttl1">Our<span class="ylw"> Faculties</span></h2>

                                <div class="clearboth"></div>
                            </div>
                        </div>
                        <div class="vc_empty_space  emp" style="height: 80px"><span class="vc_empty_space_inner"></span>
                        </div>
                        <div class="wpb_raw_code wpb_content_element wpb_raw_html desk-testi">
                            <div class="wpb_wrapper">
                                <div class="stats-bg clearfix">
                                    <div class="animate">
                                        <ul class="clearfix">


                                            <li><img class="rte" data-src="assets/images/clients/accenture.jpg"
                                                    alt="logo" src="assets/images/clients/accenture.jpg"></li>
                                            <li><img class="rte" data-src="assets/images/clients/aon-logo.png"
                                                    alt="logo" src="assets/images/clients/aon-logo.png"></li>
                                            <li><img class="rte" data-src="assets/images/clients/cape.jpg" alt="logo"
                                                    src="assets/images/clients/cape.jpg"></li>
                                            <li><img class="rte" data-src="assets/images/clients/cts.jpg" alt="logo"
                                                    src="assets/images/clients/cts.jpg"></li>

                                            <li><img class="rte" data-src="assets/images/clients/hire_comp_1.png"
                                                    alt="logo" src="assets/images/clients/hire_comp_1.png"></li>
                                            <li><img class="rte" data-src="assets/images/clients/hire_comp_2.png"
                                                    alt="logo" src="assets/images/clients/hire_comp_2.png"></li>
                                            <li><img class="rte" data-src="assets/images/clients/hire_comp_3.png"
                                                    alt="logo" src="assets/images/clients/hire_comp_3.png"></li>
                                            <li><img class="rte" data-src="assets/images/clients/hire_comp_10.png"
                                                    alt="logo" src="assets/images/clients/hire_comp_10.png"></li>

                                            <li><img class="rte" data-src="assets/images/clients/hire_comp_14.png"
                                                    alt="logo" src="assets/images/clients/hire_comp_14.png"></li>
                                            <li><img class="rte" data-src="assets/images/clients/hp.jpg" alt="logo"
                                                    src="assets/images/clients/hp.jpg"></li>
                                            <li><img class="rte" data-src="assets/images/clients/ibm.jpg" alt="logo"
                                                    src="assets/images/clients/ibm.jpg"></li>
                                            <li><img class="rte" data-src="assets/images/clients/infoys.jpg" alt="logo"
                                                    src="assets/images/clients/infoys.jpg"></li>

                                            <li><img class="rte" data-src="assets/images/clients/mphasis-logo.png"
                                                    alt="logo" src="assets/images/clients/mphasis-logo.png"></li>
                                            <li><img class="rte" data-src="assets/images/clients/nokia-logo.png"
                                                    alt="logo" src="assets/images/clients/nokia-logo.png"></li>
                                            <li><img class="rte" data-src="assets/images/clients/wipro-1.jpg" alt="logo"
                                                    src="assets/images/clients/wipro-1.jpg"></li>
                                            <li><img class="rte" data-src="assets/images/clients/zoho-logo.png"
                                                    alt="logo" src="assets/images/clients/zoho-logo.png"></li>



                                        </ul>

                                    </div>
                                    <div class="round round1">
                                        <span class="sm-round"></span>
                                        <div class="content">
                                           
                                            <h4>99%</h4>
                                            <p class="placement"> Placements</p>
                                        </div>
                                    </div>
                                    <div class="round round2">
                                        <span class="sm-round"></span>
                                        <div class="content">
                                           
                                            <h4>5600+</h4>

                                            <p class="alumni">Successful Alumni worldwide</p>
                                        </div>
                                    </div>
                                    <div class="round round3">
                                        <span class="sm-round"></span>
                                        <div class="content">
                                           
                                                
                                            <h4>300+</h4>

                                            <p class="com">companies hiring <br>world wide</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>



                    </div>
                </div>

            </div>

        </div>

    </div>



    <!--  event  -->
    <div class="box1">
        <!----> <p class="text1"> METAVERSE</p> 
        <div class="flip-box">
            <div class="flip-box-inner">
              <div class="flip1"> </div>
              <div class="flip-box-back">
                <p id="max1">"Experience our International Conference in the metaverse: a convergence of thought leaders, global perspectives, and groundbreaking insights. Engage in a virtual realm where ideas transcend borders, shaping the future of industries worldwide." </p>
              </div>
            </div>
          </div>
        
    </div>

        <div class="box2">
           <p class="text2"> IEEE</p>
           <div class="flip-box">
            <div class="flip-box-inner">
              <div class="flip2"> </div>
              <div class="flip-box-back">
                <p id="max1">"Experience our International Conference in the metaverse: a convergence of thought leaders, global perspectives, and groundbreaking insights. Engage in a virtual realm where ideas transcend borders, shaping the future of industries worldwide." </p>
              </div>
            </div>
          </div>

        </div>

        <div class="box3">
            <p class="text3"> IDEATHON </p> 
            <div class="flip-box">
                <div class="flip-box-inner">
                  <div class="flip3"> </div>
                  <div class="flip-box-back">
                    <p id="max1">"Experience our International Conference in the metaverse: a convergence of thought leaders, global perspectives, and groundbreaking insights. Engage in a virtual realm where ideas transcend borders, shaping the future of industries worldwide." </p>
                  </div>
                </div>
              </div>

        </div>

        <div class="box4">
            <p class="text4"> INTERNATIONAL CONFERENCE </p>
            <div class="flip-box">
                <div class="flip-box-inner">
                  <div class="flip4"> </div>
                  <div class="flip-box-back">
                    <p id="max1">"Experience our International Conference in the metaverse: a convergence of thought leaders, global perspectives, and groundbreaking insights. Engage in a virtual realm where ideas transcend borders, shaping the future of industries worldwide." </p>
                  </div>
                </div>
              </div>
             
              

        </div>

    



    <!--footer-->
    <div class="footer">
    </div>
    <div class="rule"> </div>
   
    <div class="slide"> </div>
    <img  src="mail.png" alt="mail" class="mail">
      <p class="mtext">ithod@panimalar.ac.in
        <br> info@panimalar.ac.in
      </p>
    <img  src="call.png" alt="call" class="call">
        <p class="ctext">+044-55555
        <br> +044-66666
        <img class="loc" src="loc.png" alt="location">
        <div>
            <!-- Facility-->
            <p class="p1"> Facilities </p> 
            <a class="p2" href="https://panimalar.ac.in/green-campus.php">Green Campus </a>
            <a class="p3" href="https://panimalar.ac.in/internet.php">Internet </a>
            <a class="p4" href="https://panimalar.ac.in/sports.php">Sports </a>
            <a class="p5" href="https://panimalar.ac.in/transport.php">Transport </a>
            <a class="p6" href="https://panimalar.ac.in/mess.php">Mess </a>
            <a class="p7" href="https://panimalar.ac.in/hostel.php">Hostel </a>
          
            <!-- Facility-->
            <p class="a1"> Developements </p>
            <a class="a2" href="https://panimalar.ac.in/research-downloads.php"> Research </a>
            <a class="a3" href="https://panimalar.ac.in/program-curriculum.php">Program & Curriculum </a>
            <a class="a4" href="https://panimalar.ac.in/assets/pdf/Audit-Statements.pdf">Audit Statements </a>
            <a class="a5" href="https://panimalar.ac.in/assets/pdf/PEC-HR-policy_compressed_compressed.pdf">Human Resource Policy </a>
            <a class="a6" href="https://panimalar.ac.in/infrastructures.php">Infrastructures </a>
            
            <!--To now-->
            <p class="v1"> To Know About </p> 
            <a class="v2" href="https://panimalar.ac.in/admission-information.php"> Admission Information </a>
            <a class="v3" href="https://panimalar.ac.in/enquiry/"> How to Apply </a>
            <a class="v4" href="https://panimalar.ac.in/admission-information.php"> Lateral Entry </a>
            
            <!--To now-->
            <p class="s1"> Address </p> 
            <a class="s2" href="https://www.google.com/maps/place/Panimalar+Engineering+College/@13.0489049,80.0754642,15z/data=!4m6!3m5!1s0x3a5261c68a9f3031:0xab41c8bdcf32ad47!8m2!3d13.0489049!4d80.0754642!16s%2Fm%2F03d0n7q?entry=ttu"> Bangalore Trunk Road,<br> Varadharajapuram, Poonamallee,<br>Chennai – 600 123. </a>
        
        </div>

<p id="dev">-Venkatesan Senthamilselvan -Tharshan k -Gokul T -Mohammed Ayaan -Mohammed Ashath -Pretheep M...</p>
        
         <script>
            

  const goDownButton = document.getElementById("goDownButton");

  goDownButton.addEventListener("click", function() {
    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: "smooth" // Optional for smooth scrolling
    });
  });

// Get the button element
const btn = document.getElementById("myBtn");

// When the user clicks on the button, scroll to the top smoothly
btn.addEventListener("click", function() {
  window.scrollTo({ top: 0, behavior: "smooth" });
});


function scrollWin(x, y)
 {
  window.scrollBy(x, y);
};


</script>




</body>
</html>
